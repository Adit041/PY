shiboken_library_soversion = str(6.5)

version = "6.5.2"
version_info = (6, 5, 2, "", "")

__build_date__ = '2023-10-08T08:13:31+00:00'




__setup_py_package_version__ = '6.5.2'
